$(document).ready(function(){
	"use strict";


});

$(window).on('load', function(){
	"use strict";
	setTimeout(function(){
		$('.preloader').addClass('inactive');
	}, 500);
	
});

